<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
{
    Schema::table('purchases', function (Blueprint $table) {

        $table->string('invoice_no')->nullable();

        $table->foreignId('user_id')
            ->nullable()
            ->constrained('users')
            ->onDelete('cascade');

        $table->enum('status', [
            'pending',
            'completed',
            'cancelled'
        ])->default('completed');

    });
}

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('purchases', function (Blueprint $table) {
            //
        });
    }
};
